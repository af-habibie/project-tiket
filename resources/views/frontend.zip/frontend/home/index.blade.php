@extends("frontend.layout.template")

@yield("")