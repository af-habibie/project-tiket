<div class="slider2">
    <div class="badg">
        <p><a href="#">Latest.</a></p>
    </div>
    <a href="#"><img src="{{ asset('img/post/1.png') }}" alt="MyPassion" /></a>
    <p class="caption"><a href="#">We Are News.</a> Donec bibendum dolor at ante. Proin neque dui, pre tium quis fringilla ut,  sodales sed metus. </p>
</div>
<div class="slider3">
    <a href="#"><img src="{{ asset('img/post/2.png') }}" alt="MyPassion" /></a>
    <p class="caption"><a href="#">Happy Birthday, blue jeans! </a></p>
</div>
<div class="slider3">
    <a href="#"><img src="{{ asset('img/post/3.png') }}" alt="MyPassion" /></a>
    <p class="caption"><a href="#">Fantasy Family Photos </a></p>
</div>