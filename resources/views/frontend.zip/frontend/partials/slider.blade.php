<section id="slider">
    <div class="container">
        <div class="main-slider">
            <div class="badg">
                <p><a href="#">Popular.</a></p>
            </div>
            <div class="flexslider">
                <ul class="slides">
                    <li>
                        <img src="{{ asset('img/flexslider/1.png') }}" alt="MyPassion" />
                        <p class="flex-caption"><a href="#">Google wants more women in tech.</a> Donec bibendum dolor at ante. Proin neque dui, pre tium quis fringilla ut,  sodales sed. </p>
                    </li>
                    <li>
                        <img src="{{ asset('img/flexslider/3.png') }}" alt="MyPassion" />
                        <p class="flex-caption"><a href="#">Small Businesses Surge against all expectations.</a> Donec bibendum dolor at ante. Proin neque dui, pre tium quis fringilla ut,  sodales sed. </p>
                    </li>
                    <li>
                        <img src="{{ asset('img/flexslider/5.png') }}" alt="MyPassion" />
                        <p class="flex-caption"><a href="#">Drones: Future of disaster response?</a> Donec bibendum dolor at ante. Proin neque dui, pre tium quis fringilla ut,  sodales sed. </p>
                    </li>
                    <li>
                        <img src="{{ asset('img/flexslider/4.png') }}" alt="MyPassion" />
                        <p class="flex-caption"><a href="#">Hollywood cowboys' retreat. </a> Donec bibendum dolor at ante. Proin neque dui, pre tium quis fringilla ut,  sodales sed. </p>
                    </li>
                    <li>
                        <img src="{{ asset('img/flexslider/2.png') }}" alt="MyPassion" />
                        <p class="flex-caption"><a href="#">Stress may cause cravings.</a> Donec bibendum dolor at ante. Proin neque dui, pre tium quis fringilla ut,  sodales sed. </p>
                    </li>
                </ul>
            </div>
        </div>
        @include("frontend.partials.latest")
    </div>    
</section>